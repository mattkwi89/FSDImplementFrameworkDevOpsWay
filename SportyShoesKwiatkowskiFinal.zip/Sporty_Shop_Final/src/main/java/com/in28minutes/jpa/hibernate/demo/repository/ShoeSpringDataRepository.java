package com.in28minutes.jpa.hibernate.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.in28minutes.jpa.hibernate.demo.entity.Shoe;

@RepositoryRestResource(path="shoes")
public interface ShoeSpringDataRepository extends JpaRepository<Shoe, Long> {
	List<Shoe> findByNameAndId(String name, Long id);

	List<Shoe> findByName(String name);

	List<Shoe> countByName(String name);

	List<Shoe> findByNameOrderByIdDesc(String name);

	List<Shoe> deleteByName(String name);

	@Query("Select  c  From Shoe c where name like '%N'")
	List<Shoe> shoeWith100StepsInName();

	@Query(value = "Select  *  From Shoe c where name like '%N'", nativeQuery = true)
	List<Shoe> shoeWith100StepsInNameUsingNativeQuery();

	@Query(name = "query_get_n_shoes")
	List<Shoe> shoeWith100StepsInNameUsingNamedQuery();
}
