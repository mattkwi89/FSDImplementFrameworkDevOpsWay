package com.in28minutes.jpa.hibernate.demo.entity;

public enum ReviewRating {
	ZERO, ONE, TWO, THREE, FOUR, FIVE
}
