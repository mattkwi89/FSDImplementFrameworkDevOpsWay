package com.in28minutes.jpa.hibernate.demo.repository;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.in28minutes.jpa.hibernate.demo.DemoApplication;
import com.in28minutes.jpa.hibernate.demo.entity.Shoe;

@SpringBootTest(classes = DemoApplication.class)
public class ShoeSpringDataRepositoryTest {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	ShoeSpringDataRepository repository;

	@Test
	public void findById_shoePresent() {
		Optional<Shoe> shoeOptional = repository.findById(10001L);
		assertTrue(shoeOptional.isPresent());
	}

	@Test
	public void findById_shoeNotPresent() {
		Optional<Shoe> shoeOptional = repository.findById(20001L);
		assertFalse(shoeOptional.isPresent());
	}

	@Test
	public void playingAroundWithSpringDataRepository() {
		//Shoe shoe = new Shoe("Jordans");
		//repository.save(shoe);

		//shoe.setName("Jordans - Updated");
		//repository.save(shoe);
		logger.info("shoes -> {} ", repository.findAll());
		logger.info("Count -> {} ", repository.count());
	}

	@Test
	public void sort() {
		Sort sort = Sort.by(Sort.Direction.ASC, "name");
		logger.info("Sorted shoes -> {} ", repository.findAll(sort));
		//shoes -> [Shoe[Reebok], Shoe[ADIDAS], Shoe[New Balance]] 
	}

	@Test
	public void pagination() {
		PageRequest pageRequest = PageRequest.of(0, 3);
		Page<Shoe> firstPage = repository.findAll(pageRequest);
		logger.info("First Page -> {} ", firstPage.getContent());
		
		Pageable secondPageable = firstPage.nextPageable();
		Page<Shoe> secondPage = repository.findAll(secondPageable);
		logger.info("Second Page -> {} ", secondPage.getContent());
	}
	
	@Test
	public void findUsingName() {
		logger.info("FindByName -> {} ", repository.findByName("Reebok"));
	}

	@Test
	public void findUsingcustomersName() {
		logger.info("findUsingcustomersName -> {} ", repository.findByName("Ranga"));
	}

}
